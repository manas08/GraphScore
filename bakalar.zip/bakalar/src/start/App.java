package start;

import javax.swing.SwingUtilities;

import gui.Main;

public class App {


	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Main main = new Main();
		SwingUtilities.invokeLater(() -> {
			SwingUtilities.invokeLater(() -> {
				SwingUtilities.invokeLater(() -> {
					SwingUtilities.invokeLater(() -> {
						main.present();
					});
				});
			});
		});
	}

}
